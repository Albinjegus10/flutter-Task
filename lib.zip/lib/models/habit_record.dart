import 'package:flutter/material.dart';

class HabitRecord {
  final DateTime date;
  final bool completed;
  final TimeOfDay? completedTime;

  HabitRecord({
    required this.date,
    this.completed = false,
    this.completedTime,
  });

  Map<String, dynamic> toJson() => {
    'date': date.toIso8601String(),
    'completed': completed,
    'completedTime': completedTime != null
      ? '${completedTime!.hour}:${completedTime!.minute}'
      : null,
  };

  factory HabitRecord.fromJson(Map<String, dynamic> json) {
    return HabitRecord(
      date: DateTime.parse(json['date']),
      completed: json['completed'] ?? false,
      completedTime: json['completedTime'] != null
        ? TimeOfDay(
            hour: int.parse(json['completedTime'].split(':')[0]),
            minute: int.parse(json['completedTime'].split(':')[1])
          )
        : null,
    );
  }
}