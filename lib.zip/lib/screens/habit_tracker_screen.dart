import 'package:flutter/material.dart';
import '../models/habit.dart';
import '../models/habit_record.dart';
import '../services/habit_service.dart';
import '../services/alarm_manager.dart';
import '../widgets/habit_calendar.dart';
import '../widgets/habit_stats_chart.dart';

class HabitTrackerScreen extends StatefulWidget {
  @override
  _HabitTrackerScreenState createState() => _HabitTrackerScreenState();
}

class _HabitTrackerScreenState extends State<HabitTrackerScreen> {
  final HabitService _habitService = HabitService();
  List<Habit> _habits = [];

  @override
  void initState() {
    super.initState();
    _loadHabits();
  }

  Future<void> _loadHabits() async {
    final habits = await _habitService.loadHabits();
    setState(() {
      _habits = habits;
    });
  }

  void _toggleHabitCompletion(Habit habit, DateTime date) async {
    final existingRecord = habit.records.firstWhere(
      (record) => 
        record.date.year == date.year && 
        record.date.month == date.month && 
        record.date.day == date.day,
      orElse: () => HabitRecord(date: date),
    );

    final newRecord = HabitRecord(
      date: date,
      completed: !existingRecord.completed,
      completedTime: !existingRecord.completed ? TimeOfDay.now() : null,
    );

    final updatedRecords = List<HabitRecord>.from(habit.records);
    final recordIndex = updatedRecords.indexWhere(
      (record) => 
        record.date.year == date.year && 
        record.date.month == date.month && 
        record.date.day == date.day
    );

    if (recordIndex >= 0) {
      updatedRecords[recordIndex] = newRecord;
    } else {
      updatedRecords.add(newRecord);
    }

    final updatedHabit = habit.copyWith(records: updatedRecords);
    final habitIndex = _habits.indexWhere((h) => h.id == habit.id);

    setState(() {
      _habits[habitIndex] = updatedHabit;
    });

    await _habitService.saveHabits(_habits);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Habit Tracker', style: TextStyle(color: Colors.white),),
          bottom: TabBar(
            labelColor: Colors.white, // This sets the selected tab text color to white
  unselectedLabelColor: Colors.white60, 
            tabs: [
              Tab(text: 'List'),
              Tab(text: 'Calendar'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildHabitList(),
            _buildCalendarView(),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _showAddHabitDialog(),
          child: Icon(Icons.add),
        ),
      ),
    );
  }

  Widget _buildHabitList() {
    return _habits.isEmpty
      ? Center(
          child: Text(
            'No habits yet!\nTap + to add a new habit',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey, fontSize: 16),
          ),
        )
      : ListView.builder(
          itemCount: _habits.length,
          itemBuilder: (context, index) {
            final habit = _habits[index];
            return Card(
              child: ExpansionTile(
                title: Text(habit.title),
                subtitle: Text(
                  'Completion Rate: ${(habit.completionRate * 100).toStringAsFixed(1)}%'
                ),
                trailing: Checkbox(
                  value: habit.isCompletedToday,
                  onChanged: (_) => _toggleHabitCompletion(
                    habit, 
                    DateTime.now(),
                  ),
                ),
                children: [
                  Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        if (habit.description.isNotEmpty)
                          Text(habit.description),
                        SizedBox(height: 8),
                        HabitStatsChart(habit: habit),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
  }

  Widget _buildCalendarView() {
    return ListView.builder(
      itemCount: _habits.length,
      itemBuilder: (context, index) {
        final habit = _habits[index];
        return Card(
          margin: EdgeInsets.all(8),
          child: Column(
            children: [
              ListTile(
                title: Text(habit.title),
                subtitle: Text(habit.description),
              ),
              HabitCalendar(
                habit: habit,
                onDayToggle: (DateTime selectedDay, bool isCompleted) {
        // Define what should happen when a day is toggled
        print("Toggled $selectedDay to $isCompleted");
        // You may need to update state here
      },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showAddHabitDialog() {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    List<int> selectedDays = [];
    TimeOfDay? reminderTime;
    int targetFrequency = 7;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Create New Habit'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  decoration: InputDecoration(
                    labelText: 'Habit Name',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                TextField(
                  controller: descriptionController,
                  decoration: InputDecoration(
                    labelText: 'Description (Optional)',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                Text('Select Days:'),
                Wrap(
                  spacing: 8,
                  children: List.generate(7, (index) {
                    final days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    return ChoiceChip(
                      label: Text(days[index]),
                      selected: selectedDays.contains(index),
                      onSelected: (bool selected) {
                        setState(() {
                          if (selected) {
                            selectedDays.add(index);
                          } else {
                            selectedDays.remove(index);
                          }
                        });
                      },
                    );
                  }),
                ),
                SizedBox(height: 16),
                ListTile(
                  title: Text('Set Reminder'),
                  trailing: IconButton(
                    icon: Icon(Icons.access_time),
                    onPressed: () async {
                      final time = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.now(),
                      );
                      if (time != null) {
                        setState(() {
                          reminderTime = time;
                        });
                      }
                    },
                  ),
                  subtitle: reminderTime != null
                    ? Text('Reminder set for ${reminderTime!.format(context)}')
                    : Text('No reminder set'),
                ),
                SizedBox(height: 16),
                Text('Target Frequency: $targetFrequency times/week'),
                Slider(
                  value: targetFrequency.toDouble(),
                  min: 1,
                  max: 7,
                  divisions: 6,
                  label: targetFrequency.round().toString(),
                  onChanged: (double value) {
                    setState(() {
                      targetFrequency = value.round();
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (titleController.text.isNotEmpty) {
                  final newHabit = Habit(
                    id: DateTime.now().toString(),
                    title: titleController.text,
                    description: descriptionController.text,
                    selectedDays: selectedDays,
                    reminderTime: reminderTime,
                    targetFrequency: targetFrequency,
                  );

                  setState(() {
                    _habits.add(newHabit);
                  });

                  await _habitService.saveHabits(_habits);
                  
                 // if (reminderTime != null) {
                   // await AlarmManager.scheduleHabitReminder(newHabit);
                  //}

                  Navigator.pop(context);
                }
              },
              child: Text('Create Habit'),
            ),
          ],
        ),
      ),
    );
  }
}
//