import 'package:flutter/material.dart';
import '../models/task.dart';
import '../services/task_service.dart';
import '../widgets/task_card.dart';
import '../widgets/add_task_dialog.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TaskService _taskService = TaskService();
  List<Task> _tasks = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    setState(() {
      _isLoading = true;
    });
    
    final tasks = await _taskService.loadTasks();
    
    setState(() {
      _tasks = tasks;
      _isLoading = false;
    });
  }

  Future<void> _addOrUpdateTask(Task task) async {
    final existingIndex = _tasks.indexWhere((t) => t.id == task.id);
    setState(() {
      if (existingIndex >= 0) {
        _tasks[existingIndex] = task;
      } else {
        _tasks.add(task);
      }
    });
    await _taskService.saveTasks(_tasks);
  }

  Future<void> _deleteTask(String taskId) async {
    // First remove the task from the in-memory list
    final deletedTaskIndex = _tasks.indexWhere((task) => task.id == taskId);
    final deletedTask = _tasks[deletedTaskIndex];
    
    setState(() {
      _tasks.removeWhere((task) => task.id == taskId);
    });
    
    // Then save the updated list to persistent storage
    await _taskService.saveTasks(_tasks);
    
    // Show a snackbar with undo option
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Task deleted'),
        duration: Duration(seconds: 3),
        action: SnackBarAction(
          label: 'UNDO',
          onPressed: () async {
            // Restore the deleted task
            setState(() {
              _tasks.insert(deletedTaskIndex, deletedTask);
            });
            await _taskService.saveTasks(_tasks);
          },
        ),
      ),
    );
  }

  void _showTaskDialog({Task? task}) {
    showDialog(
      context: context,
      builder: (context) => AddTaskDialog(
        onTaskAdded: _addOrUpdateTask,
        taskToEdit: task,
      ),
    );
  }

  Future<bool> _confirmDelete(BuildContext context) async {
    return await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Task'),
        content: Text('Are you sure you want to delete this task?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    ) ?? false;
  }

  @override
  Widget build(BuildContext context) {
    // Define a color scheme for the app
    final ColorScheme colorScheme = Theme.of(context).colorScheme;
    final primaryColor = Colors.indigo;
    final accentColor = Colors.indigoAccent;
    
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: primaryColor,
        title: Text(
          'My Task Planner',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Colors.white,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadTasks,
            tooltip: 'Refresh tasks',
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(accentColor),
              ),
            )
          : _tasks.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.task_alt,
                        size: 70,
                        color: Colors.grey[400],
                      ),
                      SizedBox(height: 16),
                      Text(
                        'No tasks yet!',
                        style: TextStyle(
                          color: Colors.grey[700],
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Tap + to add a new task',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 16,
                          top: 20,
                          bottom: 12,
                        ),
                        child: Text(
                          'Your Tasks (${_tasks.length})',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey[800],
                          ),
                        ),
                      ),
                      Expanded(
                        child: AnimatedSwitcher(
                          duration: Duration(milliseconds: 300),
                          child: ListView.builder(
                            padding: EdgeInsets.only(bottom: 80),
                            itemCount: _tasks.length,
                            itemBuilder: (context, index) {
                              final task = _tasks[index];
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4.0),
                                child: TaskCard(
                                  task: task,
                                  onStatusChanged: (bool value) async {
                                    final updatedTask = Task(
                                      id: task.id,
                                      title: task.title,
                                      description: task.description,
                                      dueDate: task.dueDate,
                                      priority: task.priority,
                                      isCompleted: value,
                                    );
                                    await _addOrUpdateTask(updatedTask);
                                  },
                                  onDelete: () async {
                                    final bool confirm = await _confirmDelete(context);
                                    if (confirm) {
                                      await _deleteTask(task.id);
                                    }
                                  },
                                  onEdit: () => _showTaskDialog(task: task),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showTaskDialog(),
        icon: Icon(Icons.add),
        label: Text('Add Task'),
        backgroundColor: accentColor,
        elevation: 4,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}