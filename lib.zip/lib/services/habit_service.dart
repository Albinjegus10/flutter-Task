import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/habit.dart';

class HabitService {
  static const String _habitsKey = 'habits';

  Future<void> saveHabits(List<Habit> habits) async {
    final prefs = await SharedPreferences.getInstance();
    final habitJsonList = habits.map((habit) => habit.toJson()).toList();
    await prefs.setString(_habitsKey, json.encode(habitJsonList));
  }

  Future<List<Habit>> loadHabits() async {
    final prefs = await SharedPreferences.getInstance();
    final habitsString = prefs.getString(_habitsKey);
    
    if (habitsString == null) return [];
    
    final List<dynamic> habitJsonList = json.decode(habitsString);
    return habitJsonList.map((habitJson) => Habit.fromJson(habitJson)).toList();
  }
}