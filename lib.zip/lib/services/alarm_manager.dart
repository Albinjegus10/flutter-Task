// lib/services/alarm_manager.dart
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../models/habit.dart';

class AlarmManager {
  static final FlutterLocalNotificationsPlugin 
    _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  // Initialize notification settings
  static Future<void> initialize() async {
    // Initialize timezone
    tz.initializeTimeZones();

    // Android notification details
    const AndroidInitializationSettings androidInitialize = 
      AndroidInitializationSettings('app_icon');
    
    // iOS notification details
    
    // Overall initialization settings
    const InitializationSettings initializationSettings = InitializationSettings(
      android: androidInitialize,
      
    );

    // Initialize the plugin
    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
    );
  }

  // Handle notification tap
  static Future<void> _onSelectNotification(String? payload) async {
    // Implement navigation or action when notification is tapped
    debugPrint('Notification Tapped: $payload');
  }

  // Schedule a habit reminder
  static Future<void> scheduleHabitReminder(Habit habit) async {
    // Ensure reminder time is set
    if (habit.reminderTime == null) return;

    // Create a unique ID for each habit
    int notificationId = habit.id.hashCode;

    // Android notification details
    const AndroidNotificationDetails androidPlatformChannelSpecifics = 
      AndroidNotificationDetails(
        'habit_reminder_channel',
        'Habit Reminders',
        importance: Importance.high,
        priority: Priority.high,
        showWhen: false,
      );

    
   

    // Combine platform-specific details
    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    // Calculate next occurrence time
    final now = DateTime.now();
    var scheduledTime = tz.TZDateTime(
      tz.local, 
      now.year, 
      now.month, 
      now.day, 
      habit.reminderTime!.hour, 
      habit.reminderTime!.minute
    );

    // If the time has already passed today, schedule for tomorrow
    if (scheduledTime.isBefore(tz.TZDateTime.now(tz.local))) {
      scheduledTime = scheduledTime.add(const Duration(days: 1));
    }

    // Schedule daily notification
    await _flutterLocalNotificationsPlugin.zonedSchedule(
  notificationId,
  'Habit Reminder',
  'Time to complete your habit: ${habit.title}',
  scheduledTime,
  platformChannelSpecifics,
  uiLocalNotificationDateInterpretation: 
      UILocalNotificationDateInterpretation.absoluteTime,
  matchDateTimeComponents: DateTimeComponents.time,
  androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, // ✅ Required parameter added
);

    debugPrint('Habit Reminder Scheduled for ${habit.title}');
  }

  // Cancel a specific habit's reminder
  static Future<void> cancelHabitReminder(Habit habit) async {
    int notificationId = habit.id.hashCode;
    await _flutterLocalNotificationsPlugin.cancel(notificationId);
    debugPrint('Habit Reminder Canceled for ${habit.title}');
  }

  // Cancel all scheduled notifications
  static Future<void> cancelAllReminders() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
    debugPrint('All Habit Reminders Canceled');
  }

  // Check if a habit has a reminder scheduled
  static Future<bool> isReminderScheduled(Habit habit) async {
    // This would require platform-specific implementation
    // For now, we'll return a placeholder
    return false;
  }

  // Add custom sound to notification
  static Future<void> scheduleHabitReminderWithSound(
    Habit habit, 
    String soundPath
  ) async {
    // Android sound settings
    final AndroidNotificationDetails androidPlatformChannelSpecifics = 
      AndroidNotificationDetails(
        'habit_reminder_channel',
        'Habit Reminders',
        importance: Importance.high,
        priority: Priority.high,
        sound: RawResourceAndroidNotificationSound(soundPath),
      );

    
 

    final NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
  
    );

    // Similar scheduling logic as scheduleHabitReminder
    // ...
  }
}

