import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/note.dart';

class NoteService {
  static const String _notesKey = 'notes';
  final Uuid _uuid = Uuid();

  Future<List<Note>> loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final notesJson = prefs.getStringList(_notesKey) ?? [];
    
    final notes = notesJson
        .map((json) => Note.fromJson(jsonDecode(json)))
        .toList();
    
    // Sort by updated date, then created date (most recent first)
    notes.sort((a, b) {
      final aDate = a.updatedAt ?? a.createdAt;
      final bDate = b.updatedAt ?? b.createdAt;
      return bDate.compareTo(aDate);
    });
    
    return notes;
  }

  Future<void> saveNotes(List<Note> notes) async {
    final prefs = await SharedPreferences.getInstance();
    final notesJson = notes
        .map((note) => jsonEncode(note.toJson()))
        .toList();
    
    await prefs.setStringList(_notesKey, notesJson);
  }

  String generateId() {
    return _uuid.v4();
  }

  Future<Note> createNote(String title, String content, {String? color}) async {
    final note = Note(
      id: generateId(),
      title: title,
      content: content,
      createdAt: DateTime.now(),
      color: color,
    );
    
    final notes = await loadNotes();
    notes.add(note);
    await saveNotes(notes);
    
    return note;
  }

  Future<Note> updateNote(Note note) async {
    final notes = await loadNotes();
    final index = notes.indexWhere((n) => n.id == note.id);
    
    if (index >= 0) {
      notes[index] = note.copyWith(updatedAt: DateTime.now());
      await saveNotes(notes);
      return notes[index];
    }
    
    throw Exception('Note not found');
  }

  Future<void> deleteNote(String id) async {
    final notes = await loadNotes();
    notes.removeWhere((note) => note.id == id);
    await saveNotes(notes);
  }
}