import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import '../models/habit.dart';

class HabitCalendar extends StatelessWidget {
  final Habit habit;
  final Function(DateTime, bool) onDayToggle;

 const HabitCalendar({
  required this.habit,
  required this.onDayToggle,
});

  @override
  Widget build(BuildContext context) {
    return TableCalendar(
      firstDay: DateTime.utc(2020, 1, 1),
      lastDay: DateTime.utc(2030, 12, 31),
      focusedDay: DateTime.now(),
      calendarFormat: CalendarFormat.month,
      headerStyle: HeaderStyle(
        formatButtonVisible: false,
        titleCentered: true,
      ),
      calendarStyle: CalendarStyle(
        todayDecoration: BoxDecoration(
          color: Colors.blue.shade200,
          shape: BoxShape.circle,
        ),
      ),
      calendarBuilders: CalendarBuilders(
        defaultBuilder: (context, day, focusedDay) {
          final isCompleted = habit.isCompletedOnDate(day);
          return Container(
            decoration: BoxDecoration(
              color: isCompleted ? Colors.green.shade100 : null,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '${day.day}',
                style: TextStyle(
                  color: isCompleted ? Colors.green : Colors.black,
                ),
              ),
            ),
          );
        },
        outsideBuilder: (context, day, focusedDay) {
          return Center(
            child: Text(
              '${day.day}',
              style: TextStyle(color: Colors.grey),
            ),
          );
        },
      ),
      onDaySelected: (DateTime selectedDay, DateTime focusedDay) {
  onDayToggle(selectedDay, !habit.isCompletedOnDate(selectedDay));
},
    );
  }
}