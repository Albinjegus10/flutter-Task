import 'package:flutter/material.dart';
import '../models/note.dart';
import '../services/note_service.dart';

class AddNoteDialog extends StatefulWidget {
  final Function(Note) onNoteAdded;
  final Note? noteToEdit;

  const AddNoteDialog({
    Key? key,
    required this.onNoteAdded,
    this.noteToEdit,
  }) : super(key: key);

  @override
  _AddNoteDialogState createState() => _AddNoteDialogState();
}

class _AddNoteDialogState extends State<AddNoteDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  final _noteService = NoteService();
  
  String? _selectedColor;
  
  final List<Map<String, dynamic>> _colorOptions = [
    {'name': 'White', 'value': null, 'color': Colors.white},
    {'name': 'Red', 'value': 'red', 'color': Colors.red[50]!},
    {'name': 'Green', 'value': 'green', 'color': Colors.green[50]!},
    {'name': 'Blue', 'value': 'blue', 'color': Colors.blue[50]!}, 
    {'name': 'Yellow', 'value': 'yellow', 'color': Colors.yellow[50]!},
    {'name': 'Purple', 'value': 'purple', 'color': Colors.purple[50]!},
    {'name': 'Orange', 'value': 'orange', 'color': Colors.orange[50]!},
    {'name': 'Pink', 'value': 'pink', 'color': Colors.pink[50]!},
  ];

  @override
  void initState() {
    super.initState();
    if (widget.noteToEdit != null) {
      _titleController.text = widget.noteToEdit!.title;
      _contentController.text = widget.noteToEdit!.content;
      _selectedColor = widget.noteToEdit!.color;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  Future<void> _saveNote() async {
    if (_formKey.currentState!.validate()) {
      final title = _titleController.text.trim();
      final content = _contentController.text.trim();

      Note note;
      if (widget.noteToEdit != null) {
        // Update existing note
        note = widget.noteToEdit!.copyWith(
          title: title,
          content: content,
          updatedAt: DateTime.now(),
          color: _selectedColor,
        );
      } else {
        // Create new note
        note = Note(
          id: _noteService.generateId(),
          title: title,
          content: content,
          createdAt: DateTime.now(),
          color: _selectedColor,
        );
      }

      widget.onNoteAdded(note);
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.noteToEdit != null;

    return AlertDialog(
      title: Text(isEditing ? 'Edit Note' : 'Add New Note'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter a title';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _contentController,
                decoration: InputDecoration(
                  labelText: 'Content',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
                maxLines: 5,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter note content';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              Text(
                'Note Color:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _colorOptions.map((colorOption) {
                  final isSelected = _selectedColor == colorOption['value'];
                  return InkWell(
                    onTap: () {
                      setState(() {
                        _selectedColor = colorOption['value'];
                      });
                    },
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: colorOption['color'],
                        border: Border.all(
                          color: isSelected ? Colors.indigo : Colors.grey,
                          width: isSelected ? 2 : 1,
                        ),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: isSelected
                          ? Icon(Icons.check, color: Colors.indigo, size: 20)
                          : null,
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _saveNote,
          child: Text(isEditing ? 'Update' : 'Add'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.indigo,
          ),
        ),
      ],
    );
  }
}