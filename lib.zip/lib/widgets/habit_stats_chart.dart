import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../models/habit.dart';

class HabitStatsChart extends StatelessWidget {
  final Habit habit;

  const HabitStatsChart({required this.habit});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Habit Completion Trend',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(show: false),
                  titlesData: FlTitlesData(show: false),
                  borderData: FlBorderData(show: false),
                  lineBarsData: [
                    LineChartBarData(
                      spots: _generateChartSpots(),
                      isCurved: true,
                      color: Colors.blue,
                      dotData: FlDotData(show: false),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<FlSpot> _generateChartSpots() {
    final sortedRecords = habit.records
      ..sort((a, b) => a.date.compareTo(b.date));
    
    return sortedRecords.asMap().entries.map((entry) {
      return FlSpot(
        entry.key.toDouble(), 
        entry.value.completed ? 1.0 : 0.0
      );
    }).toList();
  }
}

// Alarm Management (plugin-based implementation would be required)
class AlarmManager {
  static Future<void> scheduleHabitReminder(Habit habit) async {
    // Placeholder for platform-specific alarm scheduling
    // Would use plugins like flutter_local_notifications
    print('Scheduling reminder for ${habit.title}');
  }

  static Future<void> cancelHabitReminder(Habit habit) async {
    // Placeholder for canceling specific habit reminder
    print('Canceling reminder for ${habit.title}');
  }
}