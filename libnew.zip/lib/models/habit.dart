import 'package:flutter/material.dart';
import 'habit_record.dart';

class Habit {
  final String id;
  final String title;
  final String description;
  final List<HabitRecord> records;
  final List<int> selectedDays;
  final TimeOfDay? reminderTime;
  final String? alarmPath;
  final int targetFrequency;

  Habit({
    required this.id,
    required this.title,
    this.description = '',
    this.records = const [],
    this.selectedDays = const [],
    this.reminderTime,
    this.alarmPath,
    required this.targetFrequency,
  });

  bool isCompletedOnDate(DateTime date) {
    return records.any((record) =>
      record.date.year == date.year &&
      record.date.month == date.month &&
      record.date.day == date.day &&
      record.completed
    );
  }

  double get completionRate {
    if (records.isEmpty) return 0.0;
    return records.where((record) => record.completed).length / records.length;
  }

  bool get isCompletedToday {
    final today = DateTime.now();
    return isCompletedOnDate(today);
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'records': records.map((r) => r.toJson()).toList(),
    'selectedDays': selectedDays,
    'reminderTime': reminderTime != null 
      ? '${reminderTime!.hour}:${reminderTime!.minute}' 
      : null,
    'alarmPath': alarmPath,
    'targetFrequency': targetFrequency,
  };

  factory Habit.fromJson(Map<String, dynamic> json) {
    return Habit(
      id: json['id'],
      title: json['title'],
      description: json['description'] ?? '',
      records: (json['records'] as List?)
          ?.map((r) => HabitRecord.fromJson(r))
          .toList() ?? [],
      selectedDays: (json['selectedDays'] as List?)
          ?.map((day) => day as int)
          .toList() ?? [],
      reminderTime: json['reminderTime'] != null
          ? TimeOfDay(
              hour: int.parse(json['reminderTime'].split(':')[0]),
              minute: int.parse(json['reminderTime'].split(':')[1])
            )
          : null,
      alarmPath: json['alarmPath'],
      targetFrequency: json['targetFrequency'] ?? 7,
    );
  }

  Habit copyWith({
    String? id,
    String? title,
    String? description,
    List<HabitRecord>? records,
    List<int>? selectedDays,
    TimeOfDay? reminderTime,
    String? alarmPath,
    int? targetFrequency,
  }) {
    return Habit(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      records: records ?? this.records,
      selectedDays: selectedDays ?? this.selectedDays,
      reminderTime: reminderTime ?? this.reminderTime,
      alarmPath: alarmPath ?? this.alarmPath,
      targetFrequency: targetFrequency ?? this.targetFrequency,
    );
  }
}
