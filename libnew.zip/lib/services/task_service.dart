import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:task/models/task.dart';

class TaskService {
  static const String _storageKey = 'tasks';

  Future<void> saveTasks(List<Task> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = tasks.map((task) => task.toJson()).toList();
    await prefs.setString(_storageKey, jsonEncode(tasksJson));
  }

  Future<List<Task>> loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    
    final tasksString = prefs.getString(_storageKey);
    
    if (tasksString == null) return [];

    final tasksList = jsonDecode(tasksString) as List;
    return tasksList.map((taskJson) => Task.fromJson(taskJson)).toList();
  }
}
