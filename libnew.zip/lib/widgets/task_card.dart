import 'package:flutter/material.dart';
import 'package:task/models/task.dart';

class TaskCard extends StatelessWidget {
  final Task task;
  final Function(bool) onStatusChanged;
  final VoidCallback onDelete;
  final VoidCallback onEdit;

  const TaskCard({
    required this.task,
    required this.onStatusChanged,
    required this.onDelete,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(task.id),
      background: Container(
        color: Colors.red,
        alignment: Alignment.centerRight,
        padding: EdgeInsets.only(right: 16),
        child: Icon(Icons.delete, color: Colors.white),
      ),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDelete(),
      child: Card(
        child: InkWell(
          onTap: onEdit,
          child: Container(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _buildPriorityIndicator(),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        task.title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          decoration: task.isCompleted ? TextDecoration.lineThrough : null,
                          color: task.isCompleted ? Colors.grey : Colors.black87,
                        ),
                      ),
                    ),
                    // Delete button
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: onDelete,
                      tooltip: 'Delete task',
                      constraints: BoxConstraints(),
                      padding: EdgeInsets.all(8),
                    ),
                    Transform.scale(
                      scale: 1.2,
                      child: Checkbox(
                        value: task.isCompleted,
                        onChanged: (value) => onStatusChanged(value ?? false),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                  ],
                ),
                if (task.description.isNotEmpty) ...[
                  SizedBox(height: 8),
                  Text(
                    task.description,
                    style: TextStyle(
                      color: Colors.grey[600],
                      height: 1.3,
                    ),
                  ),
                ],
                SizedBox(height: 12),
                _buildTaskFooter(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPriorityIndicator() {
    final color = task.priority == 1 
        ? Colors.red 
        : task.priority == 2 
            ? Colors.orange 
            : Colors.green;
    
    return Container(
      width: 4,
      height: 40,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(4),
      ),
    );
  }

  Widget _buildTaskFooter(BuildContext context) {
    return Row(
      children: [
        Icon(
          Icons.calendar_today,
          size: 16,
          color: Colors.grey[600],
        ),
        SizedBox(width: 4),
        Text(
          _formatDate(task.dueDate),
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
        Spacer(),
        _buildTimeRemaining(),
      ],
    );
  }

  Widget _buildTimeRemaining() {
    final difference = task.dueDate.difference(DateTime.now());
    final color = difference.isNegative 
        ? Colors.red 
        : difference.inDays < 2 
            ? Colors.orange 
            : Colors.green;

    String timeText;
    if (difference.isNegative) {
      timeText = 'Overdue';
    } else if (difference.inDays == 0) {
      timeText = 'Due today';
    } else if (difference.inDays == 1) {
      timeText = 'Due tomorrow';
    } else {
      timeText = '${difference.inDays} days left';
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        timeText,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }
}