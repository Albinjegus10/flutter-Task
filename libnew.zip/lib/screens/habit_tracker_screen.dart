import 'package:flutter/material.dart';
import '../models/habit.dart';
import '../models/habit_record.dart';
import '../services/habit_service.dart';
import '../widgets/habit_calendar.dart';
import '../widgets/habit_stats_chart.dart';

class HabitTrackerScreen extends StatefulWidget {
  @override
  _HabitTrackerScreenState createState() => _HabitTrackerScreenState();
}

class _HabitTrackerScreenState extends State<HabitTrackerScreen> {
  final HabitService _habitService = HabitService();
  List<Habit> _habits = [];
  
  // Define app theme colors
  final Color _primaryColor = Colors.indigo; // Changed to match AppBar
  final Color _accentColor = Color(0xFFDDF7E3);
  final Color _backgroundColor = const Color.fromARGB(255, 199, 248, 189); // Your requested background
  final Color _cardColor = Colors.white;
  final Color _textColor = Color(0xFF333333);

  @override
  void initState() {
    super.initState();
    _loadHabits();
  }

  Future<void> _loadHabits() async {
    final habits = await _habitService.loadHabits();
    setState(() {
      _habits = habits;
    });
  }

  void _toggleHabitCompletion(Habit habit, DateTime date) async {
    final existingRecord = habit.records.firstWhere(
      (record) => 
        record.date.year == date.year && 
        record.date.month == date.month && 
        record.date.day == date.day,
      orElse: () => HabitRecord(date: date),
    );

    final newRecord = HabitRecord(
      date: date,
      completed: !existingRecord.completed,
      completedTime: !existingRecord.completed ? TimeOfDay.now() : null,
    );

    final updatedRecords = List<HabitRecord>.from(habit.records);
    final recordIndex = updatedRecords.indexWhere(
      (record) => 
        record.date.year == date.year && 
        record.date.month == date.month && 
        record.date.day == date.day
    );

    if (recordIndex >= 0) {
      updatedRecords[recordIndex] = newRecord;
    } else {
      updatedRecords.add(newRecord);
    }

    final updatedHabit = habit.copyWith(records: updatedRecords);
    final habitIndex = _habits.indexWhere((h) => h.id == habit.id);

    setState(() {
      _habits[habitIndex] = updatedHabit;
    });

    await _habitService.saveHabits(_habits);
  }

  // New method to delete a habit
  Future<void> _deleteHabit(Habit habit) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Habit'),
        content: Text('Are you sure you want to delete "${habit.title}"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() {
        _habits.removeWhere((h) => h.id == habit.id);
      });
      await _habitService.saveHabits(_habits);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Habit deleted successfully'),
          backgroundColor: _primaryColor,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: _backgroundColor,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.indigo,
          title: Text(
            'Habit Tracker', 
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 22,
            ),
          ),
          bottom: TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: const Color.fromARGB(59, 185, 187, 247),
            indicatorColor: _accentColor,
            indicatorWeight: 3,
            tabs: [
              Tab(
                icon: Icon(Icons.list_alt),
                text: 'List',
              ),
              Tab(
                icon: Icon(Icons.calendar_month),
                text: 'Calendar',
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildHabitList(),
            _buildCalendarView(),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _showAddHabitDialog(),
          backgroundColor: _primaryColor,
          elevation: 6,
          child: Icon(Icons.add, color: Colors.white),
        ),
      ),
    );
  }

  Widget _buildHabitList() {
    return _habits.isEmpty
      ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.assignment_outlined, 
                size: 80, 
                color: Colors.grey[400]
              ),
              SizedBox(height: 16),
              Text(
                'No habits yet!',
                style: TextStyle(
                  color: _textColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Tap + to add a new habit',
                style: TextStyle(
                  color: Colors.grey[600], 
                  fontSize: 16
                ),
              ),
            ],
          ),
        )
      : ListView.builder(
          padding: EdgeInsets.all(12),
          itemCount: _habits.length,
          itemBuilder: (context, index) {
            final habit = _habits[index];
            return Card(
              elevation: 2,
              margin: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              color: _cardColor,
              child: ExpansionTile(
                leading: CircleAvatar(
                  backgroundColor: habit.isCompletedToday 
                    ? _primaryColor 
                    : Colors.grey[300],
                  child: Icon(
                    Icons.check,
                    color: Colors.white,
                  ),
                ),
                title: Text(
                  habit.title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: _textColor,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 4),
                    Text(
                      'Completion Rate: ${(habit.completionRate * 100).toStringAsFixed(1)}%',
                      style: TextStyle(
                        color: Colors.grey[700],
                      ),
                    ),
                    SizedBox(height: 2),
                    LinearProgressIndicator(
                      value: habit.completionRate,
                      backgroundColor: Colors.grey[200],
                      valueColor: AlwaysStoppedAnimation<Color>(_primaryColor),
                    ),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.delete_outline, color: Colors.red[400]),
                      onPressed: () => _deleteHabit(habit),
                      tooltip: 'Delete habit',
                    ),
                    Checkbox(
                      value: habit.isCompletedToday,
                      activeColor: _primaryColor,
                      onChanged: (_) => _toggleHabitCompletion(
                        habit, 
                        DateTime.now(),
                      ),
                    ),
                  ],
                ),
                children: [
                  Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        if (habit.description.isNotEmpty)
                          Container(
                            width: double.infinity,
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _accentColor.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              habit.description,
                              style: TextStyle(
                                color: _textColor,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        SizedBox(height: 16),
                        HabitStatsChart(habit: habit),
                        SizedBox(height: 8),
                        _buildHabitDetails(habit),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
  }

  Widget _buildHabitDetails(Habit habit) {
    final days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(),
        Row(
          children: [
            Icon(Icons.repeat, size: 18, color: _primaryColor),
            SizedBox(width: 8),
            Text(
              'Schedule: ',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Wrap(
              spacing: 4,
              children: days.asMap().entries.map((entry) {
                final isSelected = habit.selectedDays.contains(entry.key);
                return Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isSelected ? _primaryColor : Colors.grey[200],
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    entry.value,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
        if (habit.reminderTime != null) ...[
          SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.access_time, size: 18, color: _primaryColor),
              SizedBox(width: 8),
              Text(
                'Reminder: ${habit.reminderTime!.format(context)}',
                style: TextStyle(color: _textColor),
              ),
            ],
          ),
        ],
        SizedBox(height: 8),
        Row(
          children: [
            Icon(Icons.flag, size: 18, color: _primaryColor),
            SizedBox(width: 8),
            Text(
              'Target: ${habit.targetFrequency} times/week',
              style: TextStyle(color: _textColor),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCalendarView() {
    return _habits.isEmpty
      ? Center(
          child: Text(
            'No habits to display on calendar',
            style: TextStyle(color: Colors.grey[600], fontSize: 16),
          ),
        )
      : ListView.builder(
          padding: EdgeInsets.all(12),
          itemCount: _habits.length,
          itemBuilder: (context, index) {
            final habit = _habits[index];
            return Card(
              elevation: 2,
              margin: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                habit.title,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  color: _textColor,
                                ),
                              ),
                              if (habit.description.isNotEmpty) ...[
                                SizedBox(height: 4),
                                Text(
                                  habit.description,
                                  style: TextStyle(
                                    color: Colors.grey[700],
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete_outline, color: Colors.red[400]),
                          onPressed: () => _deleteHabit(habit),
                          tooltip: 'Delete habit',
                        ),
                      ],
                    ),
                  ),
                  Divider(height: 1),
                  HabitCalendar(
                    habit: habit,
                    onDayToggle: (DateTime selectedDay, bool isCompleted) {
                      _toggleHabitCompletion(habit, selectedDay);
                    },
                  ),
                ],
              ),
            );
          },
        );
  }

  void _showAddHabitDialog() {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    List<int> selectedDays = List.generate(7, (index) => index); // Default all days selected
    TimeOfDay? reminderTime;
    int targetFrequency = 7;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text(
            'Create New Habit',
            style: TextStyle(
              color: _primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  decoration: InputDecoration(
                    labelText: 'Habit Name',
                    labelStyle: TextStyle(color: _primaryColor),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: _primaryColor, width: 2),
                    ),
                    prefixIcon: Icon(Icons.edit, color: _primaryColor),
                  ),
                ),
                SizedBox(height: 16),
                TextField(
                  controller: descriptionController,
                  decoration: InputDecoration(
                    labelText: 'Description (Optional)',
                    labelStyle: TextStyle(color: _primaryColor),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: _primaryColor, width: 2),
                    ),
                    prefixIcon: Icon(Icons.description, color: _primaryColor),
                  ),
                  maxLines: 3,
                ),
                SizedBox(height: 24),
                Text(
                  'Select Days:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: List.generate(7, (index) {
                    final days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    return FilterChip(
                      label: Text(days[index]),
                      selected: selectedDays.contains(index),
                      selectedColor: _primaryColor.withOpacity(0.2),
                      checkmarkColor: _primaryColor,
                      labelStyle: TextStyle(
                        color: selectedDays.contains(index) 
                            ? _primaryColor 
                            : _textColor,
                      ),
                      shape: StadiumBorder(
                        side: BorderSide(
                          color: selectedDays.contains(index) 
                              ? _primaryColor 
                              : Colors.grey,
                        ),
                      ),
                      onSelected: (bool selected) {
                        setState(() {
                          if (selected) {
                            selectedDays.add(index);
                          } else {
                            selectedDays.remove(index);
                          }
                        });
                      },
                    );
                  }),
                ),
                SizedBox(height: 24),
                ListTile(
                  leading: Icon(Icons.alarm, color: _primaryColor),
                  title: Text(
                    'Set Reminder',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.access_time, color: _primaryColor),
                    onPressed: () async {
                      final time = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.now(),
                        builder: (context, child) {
                          return Theme(
                            data: Theme.of(context).copyWith(
                              colorScheme: ColorScheme.light(
                                primary: _primaryColor,
                              ),
                            ),
                            child: child!,
                          );
                        },
                      );
                      if (time != null) {
                        setState(() {
                          reminderTime = time;
                        });
                      }
                    },
                  ),
                  subtitle: reminderTime != null
                    ? Text(
                        'Reminder set for ${reminderTime!.format(context)}',
                        style: TextStyle(color: _primaryColor),
                      )
                    : Text(
                        'No reminder set',
                        style: TextStyle(color: Colors.grey),
                      ),
                ),
                SizedBox(height: 24),
                Text(
                  'Target Frequency: $targetFrequency times/week',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                SizedBox(height: 8),
                SliderTheme(
                  data: SliderThemeData(
                    activeTrackColor: _primaryColor,
                    thumbColor: _primaryColor,
                    overlayColor: _primaryColor.withOpacity(0.2),
                    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12),
                  ),
                  child: Slider(
                    value: targetFrequency.toDouble(),
                    min: 1,
                    max: 7,
                    divisions: 6,
                    label: targetFrequency.round().toString(),
                    onChanged: (double value) {
                      setState(() {
                        targetFrequency = value.round();
                      });
                    },
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Cancel',
                style: TextStyle(color: Colors.grey[700]),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                if (titleController.text.isNotEmpty) {
                  final newHabit = Habit(
                    id: DateTime.now().toString(),
                    title: titleController.text,
                    description: descriptionController.text,
                    selectedDays: selectedDays,
                    reminderTime: reminderTime,
                    targetFrequency: targetFrequency,
                  );

                  setState(() {
                    _habits.add(newHabit);
                  });

                  await _habitService.saveHabits(_habits);
                  
                  // if (reminderTime != null) {
                  //   await AlarmManager.scheduleHabitReminder(newHabit);
                  // }

                  Navigator.pop(context);
                  
                  // Show success message
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('New habit created successfully'),
                      backgroundColor: _primaryColor,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Create Habit'),
            ),
          ],
        ),
      ),
    );
  }
}