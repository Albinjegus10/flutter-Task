import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ThoughtsScreen extends StatefulWidget {
  @override
  _ThoughtsScreenState createState() => _ThoughtsScreenState();
}

class _ThoughtsScreenState extends State<ThoughtsScreen> {
  final List<ThoughtEntry> _thoughts = [];
  final TextEditingController _thoughtController = TextEditingController();
  final List<String> _motivationalQuotes = [
    "The only way to do great work is to love what you do.",
    "Believe you can and you're halfway there.",
    "It does not matter how slowly you go as long as you do not stop.",
    "Quality is not an act, it is a habit.",
    "Your time is limited, don't waste it living someone else's life.",
    "The future belongs to those who believe in the beauty of their dreams.",
    "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    "Start where you are. Use what you have. Do what you can.",
    "Don't wait for opportunity. Create it.",
    "Small steps every day lead to big results.",
    "Push yourself, because no one else is going to do it for you.",
    "Be so good they can't ignore you.",
    "Every accomplishment starts with the decision to try.",
    "Dream big and dare to fail.",
    "Your limitation—it's only your imagination.",
    "Doubt kills more dreams than failure ever will.",
    "Discipline is doing what needs to be done, even when you don't feel like doing it.",
    "Make each day your masterpiece.",
    "Success doesn't come from what you do occasionally, it comes from what you do consistently.",
    "The harder you work for something, the greater you'll feel when you achieve it.",
    "Great things never come from comfort zones.",
    "Don't be pushed around by the fears in your mind. Be led by the dreams in your heart.",
    "You are capable of amazing things.",
    "Work hard in silence, let your success make the noise.",
    "If you can dream it, you can do it.",
    "Stay positive, work hard, make it happen.",
    "Believe in yourself and all that you are.",
    "Progress, not perfection.",
    "Strive for progress, not perfection.",
    "You don't have to be great to start, but you have to start to be great.",
    "The best way to predict the future is to create it.",
  ];

  String _randomQuote = "";
  String _lastQuoteDate = "";

  // Color scheme
  final Color _primaryColor = Color(0xFF6C63FF); // Purple
  final Color _secondaryColor = Color(0xFF4A43EC); // Darker purple
  final Color _accentColor = Color(0xFFFF6584); // Pink
  final Color _backgroundColor = Color(0xFFF8F9FA); // Light gray
  final Color _cardColor = Colors.white;
  final Color _textColor = Color(0xFF333333);
  final Color _lightTextColor = Color(0xFF777777);

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();

    // Load thoughts
    final thoughtsJson = prefs.getStringList('thoughts') ?? [];
    setState(() {
      _thoughts.clear();
      for (final thoughtString in thoughtsJson) {
        final thoughtMap = jsonDecode(thoughtString);
        _thoughts.add(ThoughtEntry.fromJson(thoughtMap));
      }
    });

    // Load last quote and date
    final savedQuote = prefs.getString('last_quote');
    final savedDate = prefs.getString('last_quote_date');

    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());

    if (savedQuote != null && savedDate == today) {
      setState(() {
        _randomQuote = savedQuote;
        _lastQuoteDate = savedDate ?? "";
      });
    } else {
      _getRandomQuote();
    }
  }

  Future<void> _saveThoughts() async {
    final prefs = await SharedPreferences.getInstance();
    final thoughtsJson =
        _thoughts.map((thought) => jsonEncode(thought.toJson())).toList();
    await prefs.setStringList('thoughts', thoughtsJson);
  }

  Future<void> _saveQuote() async {
    final prefs = await SharedPreferences.getInstance();
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());

    await prefs.setString('last_quote', _randomQuote);
    await prefs.setString('last_quote_date', today);

    setState(() {
      _lastQuoteDate = today;
    });
  }

  void _getRandomQuote() {
    setState(() {
      _randomQuote = _motivationalQuotes[
          DateTime.now().millisecond % _motivationalQuotes.length];
    });
    _saveQuote();
  }

  void _addThought() {
    if (_thoughtController.text.trim().isNotEmpty) {
      setState(() {
        _thoughts.add(
          ThoughtEntry(
            thought: _thoughtController.text,
            timestamp: DateTime.now(),
          ),
        );
        _thoughtController.clear();
      });
      _saveThoughts();
    }
  }

  void _deleteThought(int index) {
    setState(() {
      _thoughts.removeAt(index);
    });
    _saveThoughts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: const Color.fromARGB(255, 199, 248, 189),
      appBar: AppBar(
        title: Text(
          "Thoughts & Motivation",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: _primaryColor,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: _getRandomQuote,
            tooltip: "New quote",
          )
        ],
      ),
      body: Column(
        children: [
          // Motivational quote card
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_primaryColor, _secondaryColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Text(
                      "Daily Inspiration",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      _randomQuote,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        fontStyle: FontStyle.italic,
                        letterSpacing: 0.5,
                        color: Colors.white.withOpacity(0.9),
                        height: 1.4,
                      ),
                    ),
                    SizedBox(height: 8),
                    Icon(
                      Icons.format_quote,
                      color: Colors.white.withOpacity(0.3),
                      size: 40,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Add new thought
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              decoration: BoxDecoration(
                color: _cardColor,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _thoughtController,
                        decoration: InputDecoration(
                          hintText: "Write down your thoughts...",
                          hintStyle: TextStyle(color: _lightTextColor),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                        ),
                        style: TextStyle(color: _textColor),
                        maxLines: 2,
                        minLines: 1,
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _accentColor,
                      ),
                      child: IconButton(
                        onPressed: _addThought,
                        icon: Icon(Icons.add, color: Colors.white),
                        padding: EdgeInsets.all(12),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),

          // Thoughts list header
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
            child: Row(
              children: [
                Text(
                  "Your Thoughts",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _textColor,
                  ),
                ),
                SizedBox(width: 8),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _thoughts.length.toString(),
                    style: TextStyle(
                      color: _primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Thoughts list
          Expanded(
            child: _thoughts.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.lightbulb_outline,
                          size: 70,
                          color: _lightTextColor.withOpacity(0.3),
                        ),
                        SizedBox(height: 16),
                        Text(
                          "Your thoughts will appear here",
                          style: TextStyle(
                            color: _lightTextColor,
                            fontSize: 16,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          "Start by adding your first thought!",
                          style: TextStyle(
                            color: _lightTextColor.withOpacity(0.7),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                    itemCount: _thoughts.length,
                    itemBuilder: (context, index) {
                      final reversedIndex = _thoughts.length - 1 - index;
                      final thought = _thoughts[reversedIndex];

                      return Dismissible(
                        key: Key(thought.timestamp.millisecondsSinceEpoch
                            .toString()),
                        background: Container(
                          margin: EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.only(right: 20),
                          child: Icon(Icons.delete, color: Colors.red),
                        ),
                        onDismissed: (direction) =>
                            _deleteThought(reversedIndex),
                        child: Container(
                          margin: EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                            color: _cardColor,
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: ListTile(
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 12),
                            title: Text(
                              thought.thought,
                              style: TextStyle(
                                color: _textColor,
                                fontSize: 15,
                              ),
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 6.0),
                              child: Text(
                                DateFormat('MMM d, yyyy • h:mm a')
                                    .format(thought.timestamp),
                                style: TextStyle(
                                  fontSize: 12,
                                  color: _lightTextColor,
                                ),
                              ),
                            ),
                            trailing: Icon(
                              Icons.chevron_right,
                              color: _lightTextColor.withOpacity(0.5),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _thoughtController.dispose();
    super.dispose();
  }
}

class ThoughtEntry {
  final String thought;
  final DateTime timestamp;

  ThoughtEntry({
    required this.thought,
    required this.timestamp,
  });

  Map<String, dynamic> toJson() {
    return {
      'thought': thought,
      'timestamp': timestamp.millisecondsSinceEpoch,
    };
  }

  factory ThoughtEntry.fromJson(Map<String, dynamic> json) {
    return ThoughtEntry(
      thought: json['thought'] as String,
      timestamp: DateTime.fromMillisecondsSinceEpoch(json['timestamp'] as int),
    );
  }
}
