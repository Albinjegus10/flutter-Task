import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class GoalTrackingScreen extends StatefulWidget {
  @override
  _GoalTrackingScreenState createState() => _GoalTrackingScreenState();
}

class _GoalTrackingScreenState extends State<GoalTrackingScreen> {
  final List<Goal> _goals = [];
  final TextEditingController _goalTitleController = TextEditingController();
  final TextEditingController _goalDescriptionController = TextEditingController();
  final TextEditingController _milestoneController = TextEditingController();
  DateTime _selectedDeadline = DateTime.now().add(Duration(days: 30));
  
  // Color scheme
  final Color _primaryColor = Color(0xFF6C5CE7); // Purple
  final Color _secondaryColor = Color(0xFF00CEFF); // Light Blue
  final Color _accentColor = Color(0xFFFD79A8); // Pink
  final Color _successColor = Color(0xFF00B894); // Green
  final Color _warningColor = Color(0xFFFDCB6E); // Yellow
  final Color _dangerColor = Color(0xFFE17055); // Red
  final Color _textColor = Color(0xFF2D3436); // Dark Gray
  
  @override
  void initState() {
    super.initState();
    _loadGoals();
  }
  
  // Load goals from SharedPreferences
  Future<void> _loadGoals() async {
    final prefs = await SharedPreferences.getInstance();
    final goalsJson = prefs.getStringList('goals') ?? [];
    
    setState(() {
      _goals.clear();
      for (final goalString in goalsJson) {
        final goalMap = jsonDecode(goalString);
        _goals.add(Goal.fromJson(goalMap));
      }
    });
  }
  
  // Save goals to SharedPreferences
  Future<void> _saveGoals() async {
    final prefs = await SharedPreferences.getInstance();
    final goalsJson = _goals.map((goal) => jsonEncode(goal.toJson())).toList();
    await prefs.setStringList('goals', goalsJson);
  }
  
  void _addGoal() {
    if (_goalTitleController.text.trim().isNotEmpty) {
      setState(() {
        _goals.add(
          Goal(
            title: _goalTitleController.text,
            description: _goalDescriptionController.text,
            deadline: _selectedDeadline,
            milestones: [],
            createdAt: DateTime.now(),
          ),
        );
        _goalTitleController.clear();
        _goalDescriptionController.clear();
      });
      _saveGoals();
      Navigator.pop(context);
    }
  }
  
  void _deleteGoal(int index) {
    setState(() {
      _goals.removeAt(index);
    });
    _saveGoals();
  }
  
  void _addMilestone(int goalIndex) {
    if (_milestoneController.text.trim().isNotEmpty) {
      setState(() {
        _goals[goalIndex].milestones.add(
          Milestone(
            title: _milestoneController.text,
            isCompleted: false,
          ),
        );
        _milestoneController.clear();
      });
      _saveGoals();
      Navigator.pop(context);
    }
  }
  
  void _toggleMilestone(int goalIndex, int milestoneIndex) {
    setState(() {
      _goals[goalIndex].milestones[milestoneIndex].isCompleted = 
        !_goals[goalIndex].milestones[milestoneIndex].isCompleted;
    });
    _saveGoals();
  }
  
  double _calculateProgress(Goal goal) {
    if (goal.milestones.isEmpty) return 0.0;
    int completed = goal.milestones.where((m) => m.isCompleted).length;
    return completed / goal.milestones.length;
  }
  
  Color _getProgressColor(double progress) {
    if (progress == 1.0) return _successColor;
    if (progress > 0.75) return Color(0xFF00B894);
    if (progress > 0.5) return Color(0xFF00CEFF);
    if (progress > 0.25) return Color(0xFFFDCB6E);
    return Color(0xFFE17055);
  }
  
  void _showAddGoalDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 0,
          backgroundColor: Colors.transparent,
          child: Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Add New Goal',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: _primaryColor,
                    ),
                  ),
                  SizedBox(height: 24),
                  TextField(
                    controller: _goalTitleController,
                    decoration: InputDecoration(
                      labelText: 'Goal Title',
                      labelStyle: TextStyle(color: _textColor.withOpacity(0.7)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: _primaryColor.withOpacity(0.3)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: _primaryColor, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                    style: TextStyle(color: _textColor),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: _goalDescriptionController,
                    decoration: InputDecoration(
                      labelText: 'Description (Optional)',
                      labelStyle: TextStyle(color: _textColor.withOpacity(0.7)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: _primaryColor.withOpacity(0.3)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: _primaryColor, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                    maxLines: 3,
                    style: TextStyle(color: _textColor),
                  ),
                  SizedBox(height: 16),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.grey[50],
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _primaryColor.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today, color: _primaryColor, size: 20),
                        SizedBox(width: 12),
                        Text(
                          'Deadline: ',
                          style: TextStyle(color: _textColor.withOpacity(0.7)),
                        ),
                        TextButton(
                          onPressed: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: _selectedDeadline,
                              firstDate: DateTime.now(),
                              lastDate: DateTime.now().add(Duration(days: 3650)),
                              builder: (context, child) {
                                return Theme(
                                  data: Theme.of(context).copyWith(
                                    colorScheme: ColorScheme.light(
                                      primary: _primaryColor,
                                      onPrimary: Colors.white,
                                      surface: Colors.white,
                                      onSurface: _textColor,
                                    ),
                                    dialogBackgroundColor: Colors.white,
                                  ),
                                  child: child!,
                                );
                              },
                            );
                            if (picked != null) {
                              setState(() {
                                _selectedDeadline = picked;
                              });
                            }
                          },
                          child: Text(
                            DateFormat('MMM d, yyyy').format(_selectedDeadline),
                            style: TextStyle(
                              color: _primaryColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          'Cancel',
                          style: TextStyle(color: _textColor.withOpacity(0.6)),
                        ),
                      ),
                      SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: _addGoal,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _primaryColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                        ),
                        child: Text(
                          'Add Goal',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
  
  void _showAddMilestoneDialog(int goalIndex) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 0,
          backgroundColor: Colors.transparent,
          child: Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Add Milestone',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: _primaryColor,
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: _milestoneController,
                  decoration: InputDecoration(
                    labelText: 'Milestone',
                    labelStyle: TextStyle(color: _textColor.withOpacity(0.7)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: _primaryColor.withOpacity(0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: _primaryColor, width: 2),
                    ),
                    filled: true,
                    fillColor: Colors.grey[50],
                  ),
                  style: TextStyle(color: _textColor),
                ),
                SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text(
                        'Cancel',
                        style: TextStyle(color: _textColor.withOpacity(0.6)),
                      ),
                    ),
                    SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () => _addMilestone(goalIndex),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      ),
                      child: Text(
                        'Add',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 199, 248, 189),
      appBar: AppBar(
        title: Text(
          'Goal Tracking',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: _goals.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.flag_outlined,
                    size: 80,
                    color: _primaryColor.withOpacity(0.3),
                  ),
                  SizedBox(height: 20),
                  Text(
                    'No goals set yet',
                    style: TextStyle(
                      color: _textColor.withOpacity(0.5),
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(height: 30),
                  ElevatedButton.icon(
                    onPressed: _showAddGoalDialog,
                    icon: Icon(Icons.add, color: Colors.white),
                    label: Text(
                      'Add Your First Goal',
                      style: TextStyle(color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _primaryColor,
                      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                    ),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: _goals.length,
              itemBuilder: (context, index) {
                final goal = _goals[index];
                final progress = _calculateProgress(goal);
                final daysLeft = goal.deadline.difference(DateTime.now()).inDays;
                final progressColor = _getProgressColor(progress);
                
                return Container(
                  margin: EdgeInsets.only(bottom: 16),
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    shadowColor: _primaryColor.withOpacity(0.1),
                    child: ExpansionTile(
                      tilePadding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      title: Text(
                        goal.title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: _textColor,
                        ),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 12),
                          LinearPercentIndicator(
                            lineHeight: 8.0,
                            percent: progress,
                            backgroundColor: Colors.grey[200],
                            progressColor: progressColor,
                            barRadius: Radius.circular(10),
                            padding: EdgeInsets.zero,
                            animation: true,
                            animateFromLastPercent: true,
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(
                                Icons.calendar_today,
                                size: 14,
                                color: daysLeft < 7 && daysLeft >= 0 ? _warningColor : 
                                       daysLeft < 0 ? _dangerColor : _textColor.withOpacity(0.6),
                              ),
                              SizedBox(width: 6),
                              Text(
                                'Due: ${DateFormat('MMM d, yyyy').format(goal.deadline)} (${daysLeft >= 0 ? '$daysLeft days left' : '${-daysLeft} days overdue'})',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: daysLeft < 7 && daysLeft >= 0 ? _warningColor : 
                                         daysLeft < 0 ? _dangerColor : _textColor.withOpacity(0.6),
                                ),
                              ),
                              Spacer(),
                              Text(
                                '${(progress * 100).toStringAsFixed(0)}%',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: progressColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      children: [
                        if (goal.description.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                goal.description,
                                style: TextStyle(
                                  color: _textColor.withOpacity(0.8),
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                        Divider(
                          height: 1,
                          thickness: 1,
                          color: Colors.grey[200],
                          indent: 20,
                          endIndent: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 12.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Milestones',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: _textColor,
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.add_circle_outline, color: _primaryColor),
                                onPressed: () => _showAddMilestoneDialog(index),
                                tooltip: 'Add milestone',
                              ),
                            ],
                          ),
                        ),
                        if (goal.milestones.isEmpty)
                          Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Text(
                              'No milestones yet. Add some to track progress.',
                              style: TextStyle(
                                color: _textColor.withOpacity(0.5),
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ),
                        for (int i = 0; i < goal.milestones.length; i++)
                          Container(
                            margin: EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                              color: i % 2 == 0 ? Colors.grey[50] : Colors.white,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: ListTile(
                              contentPadding: EdgeInsets.symmetric(horizontal: 16),
                              leading: Checkbox(
                                value: goal.milestones[i].isCompleted,
                                onChanged: (value) => _toggleMilestone(index, i),
                                activeColor: _primaryColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                              title: Text(
                                goal.milestones[i].title,
                                style: TextStyle(
                                  decoration: goal.milestones[i].isCompleted
                                      ? TextDecoration.lineThrough
                                      : null,
                                  color: goal.milestones[i].isCompleted
                                      ? _textColor.withOpacity(0.5)
                                      : _textColor,
                                ),
                              ),
                              trailing: goal.milestones[i].isCompleted
                                  ? Icon(
                                      Icons.check_circle,
                                      color: _successColor,
                                      size: 20,
                                    )
                                  : null,
                            ),
                          ),
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              OutlinedButton.icon(
                                icon: Icon(Icons.delete_outline, size: 18),
                                label: Text('Delete Goal'),
                                onPressed: () => _deleteGoal(index),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: _dangerColor, side: BorderSide(color: _dangerColor.withOpacity(0.3)),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: _goals.isEmpty
          ? null
          : FloatingActionButton(
              onPressed: _showAddGoalDialog,
              child: Icon(Icons.add, color: Colors.white),
              backgroundColor: _primaryColor,
              tooltip: 'Add Goal',
              elevation: 2,
            ),
    );
  }
  
  @override
  void dispose() {
    _goalTitleController.dispose();
    _goalDescriptionController.dispose();
    _milestoneController.dispose();
    super.dispose();
  }
}

class Goal {
  final String title;
  final String description;
  final DateTime deadline;
  final List<Milestone> milestones;
  final DateTime createdAt;
  
  Goal({
    required this.title,
    required this.description,
    required this.deadline,
    required this.milestones,
    required this.createdAt,
  });
  
  // Convert Goal to JSON
  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'description': description,
      'deadline': deadline.millisecondsSinceEpoch,
      'milestones': milestones.map((m) => m.toJson()).toList(),
      'createdAt': createdAt.millisecondsSinceEpoch,
    };
  }
  
  // Create Goal from JSON
  factory Goal.fromJson(Map<String, dynamic> json) {
    return Goal(
      title: json['title'] as String,
      description: json['description'] as String,
      deadline: DateTime.fromMillisecondsSinceEpoch(json['deadline'] as int),
      milestones: (json['milestones'] as List)
          .map((m) => Milestone.fromJson(m as Map<String, dynamic>))
          .toList(),
      createdAt: DateTime.fromMillisecondsSinceEpoch(json['createdAt'] as int),
    );
  }
}

class Milestone {
  final String title;
  bool isCompleted;
  
  Milestone({
    required this.title,
    required this.isCompleted,
  });
  
  // Convert Milestone to JSON
  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'isCompleted': isCompleted,
    };
  }
  
  // Create Milestone from JSON
  factory Milestone.fromJson(Map<String, dynamic> json) {
    return Milestone(
      title: json['title'] as String,
      isCompleted: json['isCompleted'] as bool,
    );
  }
}