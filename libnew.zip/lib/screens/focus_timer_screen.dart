import 'package:flutter/material.dart';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class FocusTimerScreen extends StatefulWidget {
  @override
  _FocusTimerScreenState createState() => _FocusTimerScreenState();
}

class _FocusTimerScreenState extends State<FocusTimerScreen> with TickerProviderStateMixin {
  Timer? _timer;
  int _secondsRemaining = 25 * 60; // Default value
  bool _isRunning = false;
  bool _isBreakTime = false;
  String _currentTask = "";
  final TextEditingController _taskController = TextEditingController();
  final TextEditingController _minutesController = TextEditingController();
  final TextEditingController _breakMinutesController = TextEditingController();
  final List<FocusSession> _sessionHistory = [];
  int _completedSessions = 0;
  
  late TabController _tabController;
  late AnimationController _animationController;
  
  // Audio player
  final AudioPlayer _audioPlayer = AudioPlayer();
  
  // Notification plugin
  late FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin;
  
  // Custom time settings
  int _workTime = 25; // Default work time in minutes
  int _breakTime = 5; // Default break time in minutes
  
  // Color theme
  final Color _primaryColor = Colors.indigo;
  final Color _accentColor = Colors.indigoAccent;
  final Color _breakColor = Colors.green;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: _secondsRemaining),
    );
    _initializeNotifications();
    _loadSavedSettings();
    _loadSessionHistory();
  }
  
  // Initialize notifications
  void _initializeNotifications() {
    _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    final AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    final DarwinInitializationSettings initializationSettingsIOS =
        DarwinInitializationSettings();
    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );
    _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
    );
  }
  
  // Show notification
  Future<void> _showNotification(String title, String body) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'focus_timer_channel',
      'Focus Timer Notifications',
      importance: Importance.max,
      priority: Priority.high,
      showWhen: false,
    );
    
    const DarwinNotificationDetails iOSPlatformChannelSpecifics =
        DarwinNotificationDetails();
        
    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iOSPlatformChannelSpecifics,
    );
    
    await _flutterLocalNotificationsPlugin.show(
      0,
      title,
      body,
      platformChannelSpecifics,
    );
  }
  
  // Play alarm sound
  Future<void> _playAlarmSound() async {
    await _audioPlayer.play(AssetSource('sound/In.mp3'));
  }
  
  // Load saved settings from SharedPreferences
  Future<void> _loadSavedSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _workTime = prefs.getInt('workTime') ?? 25;
      _breakTime = prefs.getInt('breakTime') ?? 5;
      _secondsRemaining = _workTime * 60;
      _minutesController.text = _workTime.toString();
      _breakMinutesController.text = _breakTime.toString();
    });
  }
  
  // Save settings to SharedPreferences
  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('workTime', _workTime);
    await prefs.setInt('breakTime', _breakTime);
  }
  
  // Load session history from SharedPreferences
  Future<void> _loadSessionHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final sessions = prefs.getStringList('sessionHistory') ?? [];
    
    setState(() {
      _sessionHistory.clear();
      for (String sessionData in sessions) {
        final parts = sessionData.split('|');
        if (parts.length == 3) {
          _sessionHistory.add(
            FocusSession(
              task: parts[0],
              duration: Duration(seconds: int.parse(parts[1])),
              date: DateTime.parse(parts[2]),
            ),
          );
        }
      }
      _completedSessions = prefs.getInt('completedSessions') ?? 0;
    });
  }
  
  // Save session history to SharedPreferences
  Future<void> _saveSessionHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> sessions = _sessionHistory.map((session) => 
      '${session.task}|${session.duration.inSeconds}|${session.date.toIso8601String()}'
    ).toList();
    
    await prefs.setStringList('sessionHistory', sessions);
    await prefs.setInt('completedSessions', _completedSessions);
  }
  
  // Delete a session from history
  void _deleteSession(int index) {
    setState(() {
      _sessionHistory.removeAt(_sessionHistory.length - 1 - index);
    });
    _saveSessionHistory();
  }
  
  void _clearAllHistory() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Clear All History'),
          content: Text('Are you sure you want to delete all session history?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              onPressed: () {
                setState(() {
                  _sessionHistory.clear();
                  _completedSessions = 0;
                });
                _saveSessionHistory();
                Navigator.pop(context);
              },
              child: Text('Clear All'),
            ),
          ],
        );
      },
    );
  }
  
  void _startTimer() {
    if (_currentTask.isEmpty) {
      _showTaskDialog();
      return;
    }
    
    final DateTime startTime = DateTime.now();
    
    setState(() {
      _isRunning = true;
      _animationController.duration = Duration(seconds: _secondsRemaining);
      _animationController.forward(from: 0);
    });
    
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (_secondsRemaining > 0) {
          _secondsRemaining--;
        } else {
          _timer?.cancel();
          _isRunning = false;
          _animationController.stop();
          
          // Play sound and show notification
          _playAlarmSound();
          _showNotification(
            _isBreakTime ? 'Break Complete!' : 'Focus Session Complete!',
            _isBreakTime ? 'Ready to focus again?' : 'Great job! Time for a break.'
          );
          
          // Record session
          if (!_isBreakTime) {
            final duration = _workTime * 60 - _secondsRemaining;
            _sessionHistory.add(
              FocusSession(
                task: _currentTask,
                duration: Duration(seconds: duration),
                date: startTime,
              ),
            );
            _completedSessions++;
            _saveSessionHistory();
          }
          
          // Toggle between work and break
          _isBreakTime = !_isBreakTime;
          _secondsRemaining = _isBreakTime ? _breakTime * 60 : _workTime * 60;
              
          _showCompletionAlert();
        }
      });
    });
  }
  
  void _pauseTimer() {
    setState(() {
      _isRunning = false;
      _timer?.cancel();
      _animationController.stop();
    });
  }
  
  void _resetTimer() {
    setState(() {
      _timer?.cancel();
      _isRunning = false;
      _isBreakTime = false;
      _secondsRemaining = _workTime * 60;
      _animationController.reset();
    });
  }
  
  void _showTimerSettingsDialog() {
    _minutesController.text = _workTime.toString();
    _breakMinutesController.text = _breakTime.toString();
    
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Customize Timer'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _minutesController,
                decoration: InputDecoration(
                  labelText: 'Focus Time (minutes)',
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _primaryColor, width: 2.0),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 16),
              TextField(
                controller: _breakMinutesController,
                decoration: InputDecoration(
                  labelText: 'Break Time (minutes)',
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _breakColor, width: 2.0),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
              ),
              onPressed: () {
                final workTime = int.tryParse(_minutesController.text) ?? 25;
                final breakTime = int.tryParse(_breakMinutesController.text) ?? 5;
                
                setState(() {
                  _workTime = workTime > 0 ? workTime : 25;
                  _breakTime = breakTime > 0 ? breakTime : 5;
                  _resetTimer();
                });
                
                _saveSettings();
                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }
  
  void _showTaskDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('What are you working on?'),
          content: TextField(
            controller: _taskController,
            decoration: InputDecoration(
              hintText: 'Enter task name',
              border: OutlineInputBorder(),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: _primaryColor, width: 2.0),
              ),
            ),
            autofocus: true,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _primaryColor,
              ),
              onPressed: () {
                if (_taskController.text.trim().isNotEmpty) {
                  setState(() {
                    _currentTask = _taskController.text;
                    _taskController.clear();
                  });
                  Navigator.pop(context);
                  _startTimer();
                }
              },
              child: Text('Start',style: TextStyle(color: Colors.white,),),
            ),
          ],
        );
      },
    );
  }
  
  void _showCompletionAlert() {
    final String message = _isBreakTime 
        ? "Work session complete! Time for a $_breakTime minute break."
        : "Break complete! Ready for another $_workTime minute session?";
        
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: Text(
            _isBreakTime ? 'Break Time!' : 'Session Complete!',
            style: TextStyle(
              color: _isBreakTime ? _breakColor : _primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(message),
          actions: [
            _isBreakTime
                ? ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _breakColor,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                      _startTimer();
                    },
                    child: Text('Start Break'),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                          setState(() {
                            _currentTask = "";
                          });
                        },
                        child: Text('Change Task'),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                          _startTimer();
                        },
                        child: Text('Start Next Session'),
                      ),
                    ],
                  ),
          ],
        );
      },
    );
  }
  
  String _formatTime(int seconds) {
    int minutes = seconds ~/ 60;
    int remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }
  
  @override
  Widget build(BuildContext context) {
    final activeColor = _isBreakTime ? _breakColor : _primaryColor;
    
    return Scaffold(
       backgroundColor: const Color.fromARGB(255, 199, 248, 189),
      appBar: AppBar(
        title: Text(
          'Focus Timer',
          style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white,),
        ),
         centerTitle: true,
        backgroundColor: activeColor,
        bottom: PreferredSize(
      preferredSize: Size.fromHeight(kToolbarHeight),
      child: Container(
        color: const Color.fromARGB(255, 147, 245, 150), // Color between AppBar & TabBar
        child: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Timer', icon: Icon(Icons.timer)),
            Tab(text: 'History', icon: Icon(Icons.history)),
          ],
          indicatorColor: Colors.white,
          labelStyle: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    ),
  ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Timer Tab
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Current Task Section
                  if (_currentTask.isNotEmpty)
                    Card(
                      margin: EdgeInsets.only(bottom: 24),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 4,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: _isBreakTime 
                                ? [Colors.green.shade100, Colors.green.shade200]
                                : [Colors.indigo.shade100, Colors.indigo.shade200],
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            children: [
                              Text(
                                'CURRENT FOCUS',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey[800],
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                _currentTask,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              SizedBox(height: 8),
                              if (_isBreakTime)
                                Chip(
                                  label: Text('BREAK TIME'),
                                  backgroundColor: Colors.green[100],
                                  labelStyle: TextStyle(
                                    color: Colors.green[800],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  
                  // Timer Circle
                  Container(
                    width: 280,
                    height: 280,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: activeColor.withOpacity(0.3),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 280,
                          height: 280,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                blurRadius: 10,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 260,
                          height: 260,
                          child: CircularProgressIndicator(
                            value: _isRunning 
                                ? 1 - (_secondsRemaining / (_isBreakTime ? _breakTime * 60 : _workTime * 60))
                                : 0,
                            strokeWidth: 12,
                            backgroundColor: Colors.grey[300],
                            color: activeColor,
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _formatTime(_secondsRemaining),
                              style: TextStyle(
                                fontSize: 56,
                                fontWeight: FontWeight.bold,
                                color: activeColor,
                              ),
                            ),
                            Text(
                              _isBreakTime ? 'Break Time' : 'Focus Time',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  
                  SizedBox(height: 24),
                  
                  // Timer Controls
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton.icon(
                        icon: Icon(_isRunning ? Icons.pause : Icons.play_arrow,color: Colors.white,),
                        label: Text(_isRunning ? 'Pause' : 'Start',style: TextStyle(color: Colors.white,),),
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          backgroundColor: _isRunning ? Colors.orange : activeColor,
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        onPressed: _isRunning ? _pauseTimer : _startTimer,
                      ),
                      SizedBox(width: 16),
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey[200],
                        ),
                        child: IconButton(
                          icon: Icon(Icons.refresh),
                          onPressed: _resetTimer,
                          tooltip: 'Reset Timer',
                          color: Colors.grey[700],
                        ),
                      ),
                    ],
                  ),
                  
                  SizedBox(height: 32),
                  
                  // Custom Timer Settings
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Colors.white, Colors.grey.shade100],
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'TIMER SETTINGS',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[600],
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: _primaryColor.withOpacity(0.1),
                                  ),
                                  child: IconButton(
                                    icon: Icon(Icons.settings, color: _primaryColor),
                                    onPressed: _showTimerSettingsDialog,
                                    tooltip: 'Customize Timer',
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _buildTimerInfoBox(
                                  'Focus Time',
                                  '$_workTime min',
                                  _primaryColor,
                                  Icons.timer,
                                ),
                                _buildTimerInfoBox(
                                  'Break Time',
                                  '$_breakTime min',
                                  _breakColor,
                                  Icons.free_breakfast,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 24),
                  
                  // Stats
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [_primaryColor.withOpacity(0.05), _primaryColor.withOpacity(0.15)],
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              children: [
                                Text(
                                  '$_completedSessions',
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: _primaryColor,
                                  ),
                                ),
                                Text(
                                  'Sessions',
                                  style: TextStyle(
                                    color: Colors.grey[700],
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              height: 40,
                              width: 1,
                              color: Colors.grey[300],
                            ),
                            Column(
                              children: [
                                Text(
                                  _getTotalFocusTime(),
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: _primaryColor,
                                  ),
                                ),
                                Text(
                                  'Focus Time',
                                  style: TextStyle(
                                    color: Colors.grey[700],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // History Tab
          _sessionHistory.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.history,
                        size: 70,
                        color: Colors.grey,
                      ),
                      SizedBox(height: 16),
                      Text(
                        'No focus sessions recorded yet',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                )
              : Stack(
                  children: [
                    ListView.builder(
                      padding: EdgeInsets.all(16),
                      itemCount: _sessionHistory.length,
                      itemBuilder: (context, index) {
                        final session = _sessionHistory[_sessionHistory.length - 1 - index];
                        final minutes = session.duration.inMinutes;
                        final seconds = session.duration.inSeconds % 60;
                        
                        return Dismissible(
                          key: Key('${session.date.toIso8601String()}_$index'),
                          background: Container(
                            alignment: Alignment.centerRight,
                            padding: EdgeInsets.only(right: 20.0),
                            color: Colors.red,
                            child: Icon(
                              Icons.delete,
                              color: Colors.white,
                            ),
                          ),
                          direction: DismissDirection.endToStart,
                          onDismissed: (direction) {
                            _deleteSession(index);
                          },
                          child: Card(
                            margin: EdgeInsets.only(bottom: 8),
                            elevation: 2,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: ListTile(
                              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              leading: Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [_primaryColor.withOpacity(0.7), _primaryColor],
                                  ),
                                ),
                                child: Icon(Icons.timer, color: Colors.white),
                              ),
                              title: Text(
                                session.task,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              subtitle: Text(
                                '${_formatDate(session.date)}',
                                style: TextStyle(
                                  color: Colors.grey[600],
                                ),
                              ),
                              trailing: Container(
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: _primaryColor.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Text(
                                  '$minutes:${seconds.toString().padLeft(2, '0')}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: _primaryColor,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    if (_sessionHistory.isNotEmpty)
                      Positioned(
                        bottom: 16,
                        right: 16,
                        child: FloatingActionButton(
                          onPressed: _clearAllHistory,
                          backgroundColor: Colors.red,
                          child: Icon(Icons.delete_forever),
                          tooltip: 'Clear All History',
                        ),
                      ),
                  ],
                ),
        ],
      ),
    );
  }
  
  Widget _buildTimerInfoBox(String title, String value, Color color, IconData icon) {
    return Container(
      width: 120,
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color),
          SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(
              color: Colors.grey[700],
              fontSize: 12,
            ),
          ),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
  
  String _getTotalFocusTime() {
    int totalMinutes = 0;
    for (var session in _sessionHistory) {
      totalMinutes += session.duration.inMinutes;
    }
    
    final hours = totalMinutes ~/ 60;
    final minutes = totalMinutes % 60;
    
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    } else {
      return '${minutes}m';
    }
  }
  
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    if (date.year == now.year && date.month == now.month && date.day == now.day) {
      return 'Today, ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    }
    return '${date.day}/${date.month}, ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }
  
  @override
  void dispose() {
    _timer?.cancel();
    _tabController.dispose();
    _animationController.dispose();
    _taskController.dispose();
    _minutesController.dispose();
    _breakMinutesController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }
}

class FocusSession {
  final String task;
  final Duration duration;
  final DateTime date;
  
  FocusSession({
    required this.task,
    required this.duration,
    required this.date,
  });
}